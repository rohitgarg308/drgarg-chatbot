# Dr. Garg’s Dental Care - WhatsApp GPT Bot

This project uses OpenAI, FAISS, and Twilio to build a smart assistant for a dental clinic.